import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Mengambil direktori package
    pkg = get_package_share_directory('amr_robot')
    
    # Path ke file URDF robot
    urdf_file = os.path.join(pkg, 'urdf', 'Assembly_Autonomous Mobile Robot v2.urdf')
    
    # Membaca file URDF sebagai teks biasa
    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # Proteksi: Hapus deklarasi XML (<?xml...?>) jika ada 
    # agar tidak menyebabkan ValueError pada lxml parser Gazebo
    if robot_desc.startswith('<?xml'):
        robot_desc = robot_desc.split('?>', 1)[1]

    return LaunchDescription([
        # 1. Menjalankan Gazebo Server dan Client
        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
            output='screen'
        ),

        # 2. Node Robot State Publisher
        # Mengolah URDF dan mempublikasikan tf robot
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{
                'robot_description': robot_desc,
                'use_sim_time': True
            }],
            output='screen'
        ),

        # 3. Node Spawn Entity
        # Memasukkan model robot ke dalam dunia Gazebo
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=[
                '-topic', 'robot_description',
                '-entity', 'amr_robot',
                '-x', '0',
                '-y', '0',
                '-z', '0.2' # Dinaikkan ke 0.2 agar tidak nyangkut di lantai saat spawn
            ],
            output='screen'
        ),
    ])