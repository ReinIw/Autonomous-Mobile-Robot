#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

class PidDobController(Node):
    def __init__(self):
        super().__init__('pid_dob_controller')

        self.sub_target = self.create_subscription(Twist, 'cmd_vel_target', self.target_cb, 10)
        self.sub_odom = self.create_subscription(Odometry, 'odom', self.odom_cb, 10)
        self.pub_cmd = self.create_publisher(Twist, 'cmd_vel', 10)

        self.dt = 0.05 
        self.timer = self.create_timer(self.dt, self.control_loop)
        self.v_max = 1.11 

        self.v_ref = 0.0   
        self.w_ref = 0.0   
        self.v_act = 0.0   
        self.w_act = 0.0

     
        self.declare_parameter('kp', 0.1)
        self.declare_parameter('ki', 0.01) 
        self.declare_parameter('kd', 0.0)
        self.declare_parameter('alpha', 0.0)
        self.declare_parameter('tau_nom', 0.0)

        self.err_sum = 0.0
        self.err_prev = 0.0
        self.v_act_prev = 0.0
        self.u_prev = 0.0      
        self.d_est_filt = 0.0  

        self.get_logger().info("PID + DOB Controller Aktif! Mode LIVE TUNING Siap!")

    def target_cb(self, msg):
        self.v_ref = max(min(msg.linear.x, self.v_max), -self.v_max)
        self.w_ref = msg.angular.z

    def odom_cb(self, msg):
        self.v_act = msg.twist.twist.linear.x
        self.w_act = msg.twist.twist.angular.z

    def control_loop(self):
  
        kp = self.get_parameter('kp').value
        ki = self.get_parameter('ki').value
        kd = self.get_parameter('kd').value
        alpha = self.get_parameter('alpha').value
        tau_nom = self.get_parameter('tau_nom').value

        if self.v_ref == 0.0 and self.w_ref == 0.0:
            self.err_sum = 0.0
            self.d_est_filt = 0.0
            self.u_prev = 0.0
            self.pub_cmd.publish(Twist())
            return

        # ========================================================
        # A. ALGORITMA DOB
        # ========================================================
        v_dot = (self.v_act - self.v_act_prev) / self.dt
        self.v_act_prev = self.v_act

        u_nom = (tau_nom * v_dot) + self.v_act
        d_est = self.u_prev - u_nom
        
        # Alpha sekarang bisa diubah live dari terminal!
        self.d_est_filt = (1.0 - alpha) * self.d_est_filt + (alpha * d_est)
    
        # ========================================================
        # B. ALGORITMA PID
        # ========================================================
        error = self.v_ref - self.v_act
        self.err_sum += error * self.dt
        err_dot = (error - self.err_prev) / self.dt
        self.err_prev = error

        u_pid = (kp * error) + (ki * self.err_sum) + (kd * err_dot)

        # ========================================================
        # C. TOTAL SINYAL KONTROL
        # ========================================================
        u_total = self.v_ref + u_pid + self.d_est_filt
        u_total = max(min(u_total, self.v_max * 2.0), -self.v_max * 2.0)
        self.u_prev = u_total

        # ========================================================
        # D. KIRIM PERINTAH
        # ========================================================
        cmd = Twist()
        cmd.linear.x = float(u_total)
        err_w = self.w_ref - self.w_act
        cmd.angular.z = float(self.w_ref + (1.0 * err_w))
        self.pub_cmd.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = PidDobController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()